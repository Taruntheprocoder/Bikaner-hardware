---
name: Faridabad Industrial Trade
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#5a4138'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8e7166'
  outline-variant: '#e2bfb2'
  surface-tint: '#a73a00'
  primary: '#a33900'
  on-primary: '#ffffff'
  primary-container: '#cc4900'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb599'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006194'
  on-tertiary: '#ffffff'
  tertiary-container: '#007bb9'
  on-tertiary-container: '#fdfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  price-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '800'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels the heavy-duty precision of industrial supply and fuses it with the vibrant, energetic commerce rhythm of India's established commercial districts. Tailored for enterprise procurement heads, manufacturing plant supervisors, local fabricators, and B2B buyers sourcing fasteners, cutting tools, power equipment, and mill machinery, the interface balances iron-clad trust with fluid digital utility.

The design style is a synthesis of **Modern Industrial Utility and High-Contrast Indian B2B Commerce**. It moves away from generic, sterile enterprise palettes and embraces a vivid chromatic hierarchy: saturated safety cadmium, golden brass accents, verified emerald trust marks, and dense structural iron surfaces. The emotional tone is authoritative, brisk, transparent, and resilient—instilling unquestioned legitimacy via explicit verification cues (GST compliance, verified trade seller indicators, real-time inventory tiering, and bulk pricing clarity).

Surfaces are clean, tactile, and engineered with precision. Information density remains high without feeling congested, using distinct structural panels, high-contrast badges, monospaced parameter gauges, and crisp tabular data structures built for immediate decision-making.

## Colors

The palette derives its balance from industrial workshop materials and high-urgency commercial signals.

- **Primary (`#EA580C` Cadmium Rust & Safety Saffron):** Drives focal actions, call-for-quotes, "Send Inquiry" buttons, and primary action surfaces. It conveys warmth, activity, and high visibility.
- **Secondary (`#0F172A` Deep Navy Slate & Iron Dark):** Anchors headers, critical metric displays, technical parameters, and structural borders. Provides heavyweight contrast and timeless industrial authority.
- **Tertiary (`#0284C7` Royal Industrial Cyan):** Powers technical documentation downloads, CAD spec toggles, active filter states, and dimensional drawings navigation.
- **Accent Trust Tokens:**
  - **Trust Emerald (`#10B981`):** Reserved strictly for verification cues—GST Verified chips, IndiaMART TrustSEAL markers, active stock confirmation, and payment security badges.
  - **Marigold Brass (`#EAB308`):** Applied to tier incentives, bulk MOQ discount breaks, and top-rated industrial seller badges.
- **Neutrals (`#F8FAFC` to `#0F172A`):** Pure white (`#FFFFFF`) cards sit over tinted structural canvas `#F1F5F9`. Border definitions use calibrated zinc-slate `#E2E8F0` and `#CBD5E1` to simulate machined steel chamfers without visual noise.

## Typography

Typography prioritizes sharp scannability under warehouse, mobile, and field conditions. **Plus Jakarta Sans** provides geometric confidence with crisp apertures and prominent numerals essential for part numbers, threading gauges, and INR (`₹`) currency units.

- **Headlines & Titles:** Set with tighter tracking (`-0.02em`) to produce decisive, impact-driven statements in heavyweights (700 and 800).
- **Body Text:** Maintained at generous line-heights (1.5–1.6) with optimal character contrast to ensure technical specifications remain readable on lower-tier mobile displays.
- **Labels, Badges & Tags:** Kept in bold uppercase or sentence-cased medium weights with deliberate tracking (`+0.04em`) to maintain legibility at 11px and 12px sizes.
- **Price Hierarchy:** Indian Rupee glyph (`₹`) pairs tightly with bold digits, followed immediately by unit identifiers (`/ Piece`, `/ Kg`, `/ Pack`) in muted secondary tones.

## Layout & Spacing

The layout adopts a flexible 12-column grid system built around fixed structural rails on desktop and an ergonomic thumb-zone layout on mobile devices.

- **Breakpoints:**
  - **Mobile (`< 640px`):** 4 columns, 16px outer margin, sticky bottom inquiry actions.
  - **Tablet (`640px - 1024px`):** 8 columns, 24px outer margin, dual-column product cards.
  - **Desktop (`> 1024px`):** 12 columns, max-width 1360px centered, 32px margins, persistent facet filter sidebar (3 columns) and product matrices (9 columns).
- **Rhythm Rules:** All layout margins, padding units, and stack distances map to a baseline 4px/8px modular scale. Dense data layouts (specifications, inventory sheets) collapse to `space-xs` and `space-sm`, while landing pages and product showcases expand across `space-lg` and `space-xl` to maintain visual clarity.

## Elevation & Depth

This design system avoids dreamy, excessive soft blurs. Instead, it utilizes **tonal surface separation paired with crisp micro-shadows and engineered steel borders**.

- **Level 0 (Flat / Canvas):** Surface color `#F8FAFC`. Zero shadow. Used for page backgrounds and industrial specification section rails.
- **Level 1 (Structural Card):** `#FFFFFF` with a 1px solid `#E2E8F0` border and a crisp micro-shadow (`0 1px 3px 0 rgba(15, 23, 42, 0.06), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`). Used for standard hardware listings, category tiles, and parameter tables.
- **Level 2 (Active / Hover / Drawer):** Elevated `#FFFFFF` container with a defined shadow (`0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04)`) and a subtle boundary stroke `#CBD5E1`. Used for interactive quick-quote cards, cart summaries, and location details.
- **Level 3 (Modal / RFQ Inquiry Overlay):** Heavy industrial presence (`0 20px 25px -5px rgba(15, 23, 42, 0.16), 0 8px 10px -6px rgba(15, 23, 42, 0.08)`) with a dark translucent backdrop (`rgba(15, 23, 42, 0.72)`).

## Shapes

The interface embraces a **Soft Machined (0.25rem - 0.5rem)** shape language. The subtle radius echoes precision-machined steel billets, sheared tool plates, and industrial equipment chassis.

- **Base Radius (`0.25rem` / 4px):** Form fields, technical spec chips, verified trust pills, table rows, and status indicators.
- **Card & Modal Radius (`0.5rem` / 8px):** Product cards, inquiry panels, image containers, and floating bottom navigation trays.
- **Pills (Specialized Exception):** Strictly reserved for dynamic trust badges such as "GST Verified", "IndiaMART TrustSEAL", and "In-Stock Faridabad Warehouse".

## Components

### Buttons
- **Primary Inquiry CTA:** Solid Cadmium `#EA580C` background, crisp white typography, bold weight, with an inner active press effect. Hover shifts to `#C2410C`. Equipped with integrated phone/chat quote icons.
- **Secondary Procurement CTA:** Deep Navy `#0F172A` fill with `#FFFFFF` text for formal RFQ generation and quotation requests.
- **Technical Action Button:** White background, 1px border `#CBD5E1`, cyan `#0284C7` icon/text for downloading spec sheets and material test certificates.

### Verification & Trust Badges
- **TrustSEAL / GST Badge:** Emerald-tinted background `#ECFDF5`, deep green `#065F46` text, 1px solid `#A7F3D0` border, accompanied by a verified check icon.
- **Faridabad Stock Indicator:** Subtle slate container with a pulsing emerald dot indicating immediate yard pickup or dispatch readiness.

### Product & Hardware Cards
- Structure: White background, 1px border `#E2E8F0`, image container with a soft `#F8FAFC` inner background.
- Top rail: Sku code, stock status, and IndiaMART-linked badge.
- Body: Product title, grade classification (e.g., "Grade 8.8 High Tensile / SS 304"), tiered pricing (e.g., `₹14.50 / Piece` for 500+ units), and minimum order quantity (MOQ) indicator.
- Footer: Quick call button alongside an orange "Get Best Price" button.

### Form Inputs & Inquiry Drawer
- Inputs feature high-contrast `#0F172A` text, 1.5px structural borders that transition to a 2px Cadmium Orange focus ring.
- Inquiry forms prominently feature quantity stepper fields, metric/imperial unit selectors, and instant Faridabad/NCR transit estimations.

### Technical Specification Tables
- Alternating zebra rows (`#FFFFFF` and `#F8FAFC`) with dense 8px vertical padding. Left column: technical parameter in slate-500; Right column: heavy-weight specification in slate-900 (e.g., "Thread Pitch: 1.5mm", "Finish: Black Phosphate / Zinc Plated").